from datetime import date, time
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)

# Basic config
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///bus.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = "change-this-secret"

db = SQLAlchemy(app)


# Database models

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    register_no = db.Column(db.String(50), unique=True, nullable=False)
    department = db.Column(db.String(100))
    year = db.Column(db.String(20))


class Bus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bus_number = db.Column(db.String(20), unique=True, nullable=False)
    total_seats = db.Column(db.Integer, nullable=False)


class RouteMaster(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    route_name = db.Column(db.String(200), nullable=False)
    start_point = db.Column(db.String(200))
    end_point = db.Column(db.String(200))


class Trip(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    route_id = db.Column(db.Integer, db.ForeignKey("route_master.id"), nullable=False)
    bus_id = db.Column(db.Integer, db.ForeignKey("bus.id"), nullable=False)
    trip_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.String(10), nullable=False)  # simple string like "07:30"
    direction = db.Column(db.String(50), nullable=False)   # "Morning" or "Evening"

    route = db.relationship("RouteMaster", backref="trips")
    bus = db.relationship("Bus", backref="trips")


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("student.id"), nullable=False)
    trip_id = db.Column(db.Integer, db.ForeignKey("trip.id"), nullable=False)
    seat_number = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default="Booked")  # Booked / Cancelled / CheckedIn

    student = db.relationship("Student", backref="bookings")
    trip = db.relationship("Trip", backref="bookings")


def create_sample_data():
    """Create sample buses, routes and trips only once."""
    if Bus.query.first():
        return  # data already exists

    # College provided data example
    bus1 = Bus(bus_number="Bus 01", total_seats=50)
    bus2 = Bus(bus_number="Bus 02", total_seats=50)

    route1 = RouteMaster(
        route_name="Route A - City Center to College",
        start_point="City Center",
        end_point="Sathyabama University"
    )
    route2 = RouteMaster(
        route_name="Route B - Bus Stand to College",
        start_point="Main Bus Stand",
        end_point="Sathyabama University"
    )

    db.session.add_all([bus1, bus2, route1, route2])
    db.session.commit()

    # Create trips for today
    today = date.today()

    trip1 = Trip(
        route_id=route1.id,
        bus_id=bus1.id,
        trip_date=today,
        start_time="07:30",
        direction="Morning"
    )
    trip2 = Trip(
        route_id=route2.id,
        bus_id=bus2.id,
        trip_date=today,
        start_time="07:45",
        direction="Morning"
    )
    trip3 = Trip(
        route_id=route1.id,
        bus_id=bus1.id,
        trip_date=today,
        start_time="17:00",
        direction="Evening"
    )

    db.session.add_all([trip1, trip2, trip3])
    db.session.commit()


def calculate_density(booked, total):
    if total == 0:
        return "Unknown"
    percentage = int(booked / total * 100)
    if percentage <= 50:
        return f"Low ({percentage}%)"
    elif percentage <= 80:
        return f"Medium ({percentage}%)"
    else:
        return f"High ({percentage}%)"


@app.route("/")
def home():
    # For now, show trips for today
    today = date.today()
    trips = Trip.query.filter_by(trip_date=today).all()

    trips_data = []
    for t in trips:
        total_seats = t.bus.total_seats
        booked = Booking.query.filter_by(trip_id=t.id, status="Booked").count()
        density = calculate_density(booked, total_seats)

        trips_data.append(
            {
                "id": t.id,
                "route_name": t.route.route_name,
                "bus_number": t.bus.bus_number,
                "trip_date": t.trip_date,
                "start_time": t.start_time,
                "direction": t.direction,
                "total_seats": total_seats,
                "booked": booked,
                "remaining": total_seats - booked,
                "density": density,
            }
        )

    return render_template("index.html", trips=trips_data)


@app.route("/book/<int:trip_id>", methods=["GET", "POST"])
def book(trip_id):
    trip = Trip.query.get_or_404(trip_id)

    if request.method == "POST":
        name = request.form.get("name")
        register_no = request.form.get("register_no")
        department = request.form.get("department")
        year = request.form.get("year")

        if not name or not register_no:
            flash("Name and Register Number are required")
            return redirect(url_for("book", trip_id=trip_id))

        # Find or create student
        student = Student.query.filter_by(register_no=register_no).first()
        if not student:
            student = Student(
                name=name,
                register_no=register_no,
                department=department,
                year=year,
            )
            db.session.add(student)
            db.session.commit()

        # Check seats
        total_seats = trip.bus.total_seats
        booked_count = Booking.query.filter_by(trip_id=trip.id, status="Booked").count()

        if booked_count >= total_seats:
            flash("No seats available for this trip")
            return redirect(url_for("home"))

        # Next seat number is booked_count + 1
        seat_number = booked_count + 1
        booking = Booking(
            student_id=student.id,
            trip_id=trip.id,
            seat_number=seat_number,
            status="Booked",
        )
        db.session.add(booking)
        db.session.commit()

        flash(f"Seat booked successfully. Seat number: {seat_number}")
        return redirect(url_for("my_bookings", register_no=register_no))

    # GET request: show booking form
    total_seats = trip.bus.total_seats
    booked_count = Booking.query.filter_by(trip_id=trip.id, status="Booked").count()
    remaining = total_seats - booked_count

    return render_template(
        "book.html",
        trip=trip,
        total_seats=total_seats,
        booked=booked_count,
        remaining=remaining,
    )


@app.route("/my-bookings")
def my_bookings():
    register_no = request.args.get("register_no")
    if not register_no:
        flash("Please provide register number to view bookings")
        return redirect(url_for("home"))

    student = Student.query.filter_by(register_no=register_no).first()
    if not student:
        flash("No bookings found for this register number")
        return redirect(url_for("home"))

    bookings = Booking.query.filter_by(student_id=student.id).all()

    return render_template("my_bookings.html", student=student, bookings=bookings)


if __name__ == "__main__":
    with app.app_context():
        if not os.path.exists("bus.db"):
            db.create_all()
            create_sample_data()
    app.run(debug=True)
